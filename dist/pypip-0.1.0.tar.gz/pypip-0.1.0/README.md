# PyPip

Run any Python file **instantly**, without any setup.

PyPip combines python, virtualenv, and pip to launch a dedicated isolated environment, automatically figure out which packages are required (from a recursive lookup for a *pyproject.toml* or *requirements.txt*, or even just from parsing *import* statements), and then runs your python file. 

Code is run more than read, and read more than it is written. PyPip makes it easier and faster to run. 

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install PyPip.

```bash
pip install pypip
```

It might be the last time you have to *pip install* anything!

## Usage

```bash
pypip a-pandas-script

# returns 'words'
foobar.pluralize('word')

# returns 'geese'
foobar.pluralize('goose')

# returns 'phenomenon'
foobar.singularize('phenomena')
```

## License

[MIT](https://choosealicense.com/licenses/mit/)